
import java.util.Scanner;
import jdk.nashorn.api.tree.BreakTree;


public class Loby {
    public static void main(String[] args) {
        
        Scanner leitor = new Scanner(System.in);
        Integer digitado = null;
        String nome = "";
        Integer contador = 1;
        Opcao1  menu = new Opcao1();
        Opcao2 game = new Opcao2();
        Opcao3 imc = new Opcao3();
        System.out.println("Insira seu nome");
        nome = leitor.nextLine();
        System.out.println(String.format("Bem vindo a FitFlex %s \n", nome));
        
        while (contador > 0) {            
            
        
        do { 
            System.out.println("Digite a opção desejada: \n"
                    + " 1 - Ver meus macros \n"
                    + " 2 - Game \n"
                    + " 3 - IMC \n"
                    + " 4 - Sair");
            digitado = leitor.nextInt();
           
            if (digitado !=1 && digitado !=2 && digitado !=3 &&digitado != 4) {
                System.out.println("Opção inválida" + "\n"
                        + "Por favor, escolha um de nossos serviços.");
            }
          
        } while (digitado !=1 && digitado !=2 && digitado !=3 && digitado != 4);
           
            switch (digitado) {
                case 1:
                menu.macros(digitado);
                  break;
                    case 2: 
                        game.minigame(digitado);
                        break;
                        case 3:
                            imc.calculaPesoIdeal(digitado);
                         break;
                    default:
            
            
            } if (digitado == 4) {
            break;
        }
         } 
       }
   }       


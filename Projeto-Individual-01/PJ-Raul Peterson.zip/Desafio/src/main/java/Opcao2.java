
import java.util.Scanner;


public class Opcao2 {
    
    void minigame (Integer resposta ){
    
        Scanner leitor = new Scanner (System.in);

        System.out.println("_".repeat(60));
        System.out.println("Bem vindo ao Game of Calories, para uma melhor experiência \n"
                + " clique no link https://www.youtube.com/watch?v=VuZCUZ7nzpc");
             
        System.out.println("_".repeat(60));
        System.out.println("1) Qual dos alimentos a seguir pussui mais calorias: \n"
                    + " [1] Algodão doce \n"
                    + " [2] Cuzcuz \n"
                    + " [3] Pera \n"
                    + " [4] Queijo");
        
        resposta = leitor.nextInt();
        
        if (resposta == 1) {
            System.out.println("Correto!!");
        }else {
            System.out.println("Não foi dessa vez =/");
        }
        System.out.println("_".repeat(60));
        System.out.println("2)Qual dos alimentos a seguir pussui menos calorias: \n"
                    + " [1] Oreo \n"
                    + " [2] Fini \n"
                    + " [3] Morango \n"
                    + " [4] Maçã");
        
        resposta = leitor.nextInt();
        if (resposta ==3) {
            System.out.println("Tá voando!");
        }else{
            System.out.println("Achou errado!");
        }
        System.out.println("_".repeat(60));
        System.out.println("3) Exercícios cardiovasculares aumentam o "
                + "consumo de calorias? \n"
                    + " [1] Sim \n"
                    + " [2] Não \n");
        resposta = leitor.nextInt();       
        if (resposta == 1){
            System.out.println("Certa resposta!");
        }else{
            System.out.println("Nonono, você errou");
        }
        System.out.println("_".repeat(60));
        System.out.println("4)Metade de um Twix pussui calorias equivalente ao um Kiwi? \n"
                    + " [1] Verdadeiro \n"
                    + " [2] Falso \n");
        resposta = leitor.nextInt();
        if (resposta == 1) {
            System.out.println("Acertou meu caro amigo(a)");
        }else{
            System.out.println("NA TRAVEEE TAFARELLLLLL!!");
        }
        System.out.println("_".repeat(60));
        System.out.println("5) Qual desses pussui a gordura saúdavel? \n"
                    + " [1] Carne \n"
                    + " [2] Barra de ceral\n"
                    + " [3] Bacon \n"
                    + " [4] Abacate");
        resposta = leitor.nextInt();
        if (resposta == 4) {
            System.out.println("Certa respota!!!");
        }else {
            System.out.println("Errou feio, errou rude");
        }
        System.out.println("Obrigado por jogar =)");
        System.out.println("_".repeat(60));
    
    }   
       
    }
    



import java.util.Scanner;


public class Opcao1 {
    
    
    void  macros (Integer perfil){

       Scanner leitor = new Scanner(System.in);
       String genero = null;

        do {
                System.out.println("Identifique seu genero com M ou F");
                genero = leitor.nextLine();
                
                if (!genero.equalsIgnoreCase("f") && !genero.equalsIgnoreCase("m")) {
                System.out.println("Genero inválido");
            }

        } while (!genero.equalsIgnoreCase("f") && !genero.equalsIgnoreCase("m"));
        
        do {
                System.out.println("Qual seu perfil \n"
                + "1 - Sedentario (exercicio mínimo) \n"
                + "2 - Exercicio leve (1-3 dias por semana) \n"
                + "3 - Exercício moderado (3-5 dias por semana)");
           
           
           
           perfil = leitor.nextInt();
           if (perfil != 1 && perfil !=2 && perfil !=3) {
               System.out.println("Número inválido");
           }
      
        } while (perfil != 1 && perfil !=2 && perfil !=3 );
       
       Integer altura = null; 
       System.out.println("Informe sua altura (valor inteiro exemplo: 150 / 160)");
       altura = leitor.nextInt();
       
       Integer pesoCliente = null;
       System.out.println("Informe seu peso (Inteiro)");
       pesoCliente = leitor.nextInt();
       
       Integer idade = null;
       System.out.println("Informe sua idade");
       idade = leitor.nextInt();
       
       
       Double TMB = (pesoCliente * 10) + (altura * 6.25) - (idade * 5) + 5;
       Double TmbFeminino = (pesoCliente * 10) + (altura * 6.25) - (idade *5) -161; 
       Double proteina = pesoCliente * 2.5;
       Double gordura = pesoCliente * 0.8;
       Double proteinaCaloria = proteina * 4;
       Double gorduraCaloria = gordura * 9;
       Double caloriasTotais = 0.0;
       Double carbo = null;
       
        if (genero.equals("m") && perfil == 1) {
            TMB = TMB * 1.2;
            caloriasTotais = TMB - (proteinaCaloria + gorduraCaloria);
            carbo = caloriasTotais / 4 ;
            
            System.out.println("_".repeat(30));
            System.out.println(String.format("Seus macros são\n"
                    + "Calorias %.0f \n"
                    + "Proteina %.0fg \n"
                    + "Gordura %.0fg \n"
                    + "Carbo %.0fg", TMB,proteina
            , gordura, carbo));
            System.out.println("_".repeat(30));

          }else if(genero.equals("m") && perfil == 2){
            TMB = TMB * 1.37;
            caloriasTotais = TMB - (proteinaCaloria + gorduraCaloria);
            carbo = caloriasTotais / 4;
            
            System.out.println(String.format("Seus macros são\n"
                    + "Calorias %.0f \n"
                    + "Proteina %.0fg \n"
                    + "Gordura %.0fg \n"
                    + "Carbo %.0fg", TMB,proteina
            , gordura, carbo));
          }
        else if (genero.equalsIgnoreCase("m") && perfil == 3) {
            TMB = TMB * 1.55;
            caloriasTotais = TMB - (proteinaCaloria + gorduraCaloria);
            carbo = caloriasTotais / 4;
         System.out.println("_".repeat(30));      
         System.out.println(String.format("Seus macros são\n"
                    + "Calorias %.0f \n"
                    + "Proteina %.0fg \n"
                    + "Gordura %.0fg \n"
                    + "Carbo %.0fg", TMB,proteina
            , gordura, carbo));
          System.out.println("_".repeat(30));
        }
        if (genero.equalsIgnoreCase("f") && perfil == 1) {
           TmbFeminino = TmbFeminino * 1.2;
           caloriasTotais = TMB - (proteinaCaloria + gorduraCaloria);
           carbo = caloriasTotais / 4;
           System.out.println("_".repeat(30));
            System.out.println(String.format("Seus macros são\n"
                    + "Calorias %.0f \n"
                    + "Proteina %.0fg \n"
                    + "Gordura %.0fg \n"
                    + "Carbo %.0fg", TmbFeminino,proteina
            , gordura, carbo));
           System.out.println("_".repeat(30));
        }
        else if (genero.equalsIgnoreCase("f") && perfil == 2) {
           TmbFeminino = TmbFeminino * 1.37;
           caloriasTotais = TMB - (proteinaCaloria + gorduraCaloria);
           carbo = caloriasTotais / 4;
            System.out.println("_".repeat(30));
            System.out.println(String.format("Seus macros são\n"
                    + "Calorias %.0f \n"
                    + "Proteina %.0fg \n"
                    + "Gordura %.0fg \n"
                    + "Carbo %.0fg", TmbFeminino,proteina
            , gordura, carbo));
           System.out.println("_".repeat(30));
        }
        else if(genero.equalsIgnoreCase("f") && perfil == 3) {
            TmbFeminino = TmbFeminino * 1.55;
            System.out.println("_".repeat(30));
             System.out.println(String.format("Seus macros são\n"
                    + "Calorias %.0f \n"
                    + "Proteina %.0fg \n"
                    + "Gordura %.0fg \n"
                    + "Carbo %.0fg", TmbFeminino,proteina
            , gordura, carbo));
           System.out.println("_".repeat(30));
        }
    }
   }
    
       
    



import java.util.Scanner;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author raul-
 */
public class Opcao3 {
    
    
        
                
        void calculaPesoIdeal (Integer bemvindo){
        Double pesoDigitado= null;
        Double alturaDigitada = null;
        Scanner leitor = new Scanner(System.in);    
        System.out.println("Informe seu peso");
        pesoDigitado = leitor.nextDouble();
        System.out.println("Informe sua altura");
        alturaDigitada = leitor.nextDouble();
        alturaDigitada = alturaDigitada * 2; 
        Double imc = pesoDigitado / alturaDigitada;    
        System.out.println(String.format("Seu IMC é de %.2f", imc)); 
        
    
    }
    
}

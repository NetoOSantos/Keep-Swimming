package com.mycompany.projetoindividual;

public class calculadora {
    
    Integer somar(Integer numero1, Integer numero2) {
        return numero1 + numero2;
    }
     Integer subtrair(Integer numero1, Integer numero2) {
        return numero1 - numero2;
    }
      Integer multip(Integer numero1, Integer numero2) {
        return numero1 * numero2;
    }
       Integer divide(Integer numero1, Integer numero2) {
        return numero1 / numero2;
    }
}

package com.mycompany.projetoindividual;

//import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.*;

import java.util.concurrent.ThreadLocalRandom;

public class Programa {

    public static void main(String[] args) {

        Scanner leitorNum = new Scanner(System.in);
        Scanner leitorTexto = new Scanner(System.in);

        System.out.println("bip...\n \nbip...\nbip...\n");
        System.out.println("Iniciando...\n");

        System.out.println("\nBem vindo a Pokedex!!...");

        System.out.println("\b Digite seu nome...");
        String nome = leitorTexto.nextLine();
        System.out.println("Bem vindo, " + nome + " !!");

        System.out.println("Para continuar digite uma das opções a seguir!!!");
        System.out.println("1°- PokeCalculadora\n2°- PokeConta\n3°- Inical\n4°- MiniGame\n5°- Sair");

        Integer numeroDigitado = leitorNum.nextInt();
        Boolean condiçao = false;

        while (condiçao == false) {

            switch (numeroDigitado) {

                case 1:

                    System.out.println("Entrando na PokeCalculadora...");
                    System.out.println("Escolha a operação que deseja");
                    System.out.println("1°- Adiçao\n2°- Subtraçao\n3°- multiplicaçao\n4°- divisao\n5°- Sair");

                    Integer numeroDigitado2 = leitorNum.nextInt();
                    calculadora calc = new calculadora();

                    Integer num1;
                    Integer num2;

                    if (numeroDigitado2 == 1) {

                        System.out.println("Adiçao");
                        System.out.println("Digite dois numeros Inteiros...");

                        num1 = leitorNum.nextInt();
                        System.out.println("+");
                        num2 = leitorNum.nextInt();

                        System.out.println(String.format("Numero:%d + %d = ", num1, num2));
                        System.out.println(String.format(
                                "Resultado: %d", calc.somar(num1, num2)));

                        System.out.println("Obrigado!!");

                    } else if (numeroDigitado2 == 2) {

                        System.out.println("Subtraçao");
                        System.out.println("Digite dois numeros Inteiros...");

                        num1 = leitorNum.nextInt();
                        System.out.println("-");
                        num2 = leitorNum.nextInt();

                        System.out.println(String.format("Numero:%d - %d = ", num1, num2));
                        System.out.println(String.format(
                                "Resultado: %d", calc.subtrair(num1, num2)));

                        System.out.println("Obrigado!!");
                    } else if (numeroDigitado2 == 3) {

                        System.out.println("multiplicaçao");
                        System.out.println("Digite dois numeros Inteiros...");

                        num1 = leitorNum.nextInt();
                        System.out.println("*");
                        num2 = leitorNum.nextInt();

                        System.out.println(String.format("Numero:%d * %d = ", num1, num2));
                        System.out.println(String.format(
                                "Resultado: %d", calc.multip(num1, num2)));

                        System.out.println("Obrigado!!");
                    } else if (numeroDigitado2 == 4) {

                        System.out.println("divisao");
                        System.out.println("Digite dois numeros Inteiros...");

                        num1 = leitorNum.nextInt();
                        System.out.println("/");
                        num2 = leitorNum.nextInt();

                        System.out.println(String.format("Numero:%d / %d = ", num1, num2));
                        System.out.println(String.format(
                                "Resultado: %d", calc.divide(num1, num2)));

                        System.out.println("Obrigado!!");
                    } else if (numeroDigitado2 == 5) {
                        System.out.println("Saindo......\nObrigado!!");
                    }

                    condiçao = true;
                    break;

                case 2:
                    System.out.println("Bem vindo " + nome);
                    System.out.println("Entrando em sua PokeConta...");
                    System.out.println("Ops...\n Detectamos que voce ainda nao tem uma conta!");
                    System.out.println("Insira um nome de usuario e senha para continuar!");

                    System.out.println("Nome de usuario: " + nome);
                    System.out.println("Insira sua senha");

                    String senha = leitorTexto.nextLine();
                    System.out.println("Insira novamente sua senha");
                    String confirmaSenha = leitorTexto.nextLine();

                    Boolean condiçaoSenha = false;

                    while (condiçaoSenha == false) {

                        if (senha.equals(confirmaSenha)) {

                            condiçaoSenha = true;
                            break;
                        }

                        System.out.println("Senha Incorreta, Tente novamente");
                        confirmaSenha = leitorTexto.nextLine();
                    }

                    
                    System.out.println("Escolha um Tipo: \n1°- Agua\n2°- Fogo\n3°-Planta ");
                    Integer tipo = leitorNum.nextInt();
                    
                    switch (tipo) {
                        case 1:
                            System.out.println("Seu Pokemon indicado é: Agua. ");
                            break;
                            
                             case 2:
                            System.out.println("Seu Pokemon indicado é: Fogo. ");
                            break;
                            
                             case 3:
                            System.out.println("Seu Pokemon indicado é: Planta. ");
                            break;
                             case 4:
                            System.out.println("Seu Pokemon indicado é o secreto: Eletrico. ");
                            break;
                        default:
                           System.out.println("Tipo Invalido! ");
                    }
                    
                    
                    
                    condiçao = true;
                    break;

                case 3:
                    System.out.println("Sorteio...");
                    System.out.println("Aguarde...");

                    System.out.println("Bem vindo, hora de saber quem sera seu companheiro!!!");

                    System.out.println("Aguarde...");

                    Integer pokeSorteado;

                    List lista = new ArrayList();
                    lista.add("Charmander:\nchar...char");
                    lista.add("Bulbasaur:\nBulba...Bulbasaur");
                    lista.add("squirtle:\nsquiiirtleeee...");
                    lista.add("Pikachu:\n Pika...Pikaa");
                    lista.add("Eevee\nVeee...");

                    pokeSorteado = ThreadLocalRandom.current().nextInt(0, 5);
//                               

                    System.out.println("Parabens, seu Pokemon foi sorteado!!");
                    System.out.println(String.format("Seu inical é \n%s  !!! ", lista.get(pokeSorteado)));

                    condiçao = true;
                    break;

                case 4:
                    
                     System.out.println("Nao consegui acabar o desafio por alguns imprevistos,\n Farei nesse final de semana do dia 05/03 e mandarei na segunda....");
                    
                    
                    
                    

                    System.out.println("\n******************MiniGame*********************\n");
                    System.out.println("Bem vindo a SafariZone");
                    System.out.println("Carregando....\n");

                    System.out.println(
                            String.format("Professor Carvalho: Ola, %s", nome));
                    System.out.println("E bom ter voce por aqui!!!");
                    System.out.println("Essa e a Zona do Safari ou Safari Zone!");
                    System.out.println("E aqui que voce vai conseguir capturar seus pokemons!!!\n \tPodendo se tornar um mestre Pokemon!!");

                    Boolean explicacao = false;
                    Integer respost = 0;

                    while (explicacao == false) {

                        if (respost == 1) {
                            explicacao = true;
                            break;

                        } else {
                            System.out.println("Vou le explicar as regras para que possa entender melhor: \n");

                            System.out.println("Ao entrar na safariZone voce vai poder encontrar pokemons.\nAo encontrar um voce tera quatro opçoes."
                                    + "\nSendo: \n1°- Jogar a pokebola (Pokebolas podem ser arremeçadas e se tiver sorte voce pode capturar seus pokemons)"
                                    + "\n2°- Jogar uma guloseima (Guloseimas aumentam sua chance de captura)"
                                    + "\n3°- Jogar uma pedra(Pedras evitam podem evitar que os pokemons fujam mas torna mais dificil a captura)"
                                    + "\n4°- Fugir(Ao fugir voce abandona a possibilidade de capturar ele!\n"
                                    + "Entendeu??!!!\n(1°-Yes/ 2°-No)");

                            respost = leitorNum.nextInt();

                        }
                    }
                    System.out.println(
                            String.format("%s Entrou na Safari zone!!", nome));

                    Integer fazendo;

                    System.out.println("Oque vai fazer?\n1°- Andar\n2°-Sair");
//
//                    while () {
//                        switch (var) {
//                            case val:
//
//                                break;
//                            default:
//                                throw new AssertionError();
//                        }
//
//                    }

                    condiçao = true;
                    break;

                case 5:

                    System.out.println("Nao desligue ainda ");
                    System.out.println("Encerrando......");
                    System.out.println("Obrigado...");
                    System.out.println("///////////////////////////////////////////FIM///////////////////////////////////////////");

                    condiçao = true;
                    break;

                default:
                    System.out.println("Numero Invalido...\nPor favor, tente novamente!");
                    numeroDigitado = leitorNum.nextInt();
                    break;

            }

        }

    }

}

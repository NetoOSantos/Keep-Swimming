package com.mycompany.projetoindividual;

public class Menu {
    
    
    
}

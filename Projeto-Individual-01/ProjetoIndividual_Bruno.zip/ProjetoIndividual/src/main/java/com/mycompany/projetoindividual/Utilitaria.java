
package com.mycompany.projetoindividual;

import java.text.DecimalFormat;
import java.util.Scanner;
import java.util.concurrent.ThreadLocalRandom;


public class Utilitaria {
       Scanner leitor = new Scanner(System.in);
    
    
    String menu (String opcoesMenu){
        
        opcoesMenu = "\nSelecione o que você quer saber:\n"
                + "1-Minha média até agora\n"
                + "2-Preciso de ajuda\n"
                + "3-Como estou de faltas\n"
                + "4-Encerrar programa\n"
                + "5-Joguinho!";
        
        
        
        return opcoesMenu;
    }
    
   Double calcularMedia(Double continuada, Double integrada){
      
       
     Double media =  continuada * 0.4 + integrada * 0.6;
    
       
       return media;
    }
   
   String precisoDeAjuda (String documentacao, String materia, String social) {
   
       
        String  ajudaResultado1;
        String  ajudaResultado2;
        String  ajudaResultado3;
        
          System.out.println("Digite apenas Sim ou Não");
       System.out.println("Você tem alguma dúvida com o relação a "
                       + "documentação da faculdade?");
       
             documentacao = leitor.nextLine();
               
     
    
          System.out.println("É alguma dúvida com relação a matéria?\n");
                  materia = leitor.nextLine();
                  
      
     
          System.out.println("É alguma dúvida com relação a interações"
                   + " sociais no trabalho"
                   + ",faculdade ou quaisquer outros tipos\n");
                 social = leitor.nextLine();
    
        
      if(documentacao.equals("Sim")) {
        ajudaResultado1 =  "Abra um chamado no moodle e busque falar com"
                    + "a secretaria com relação a documentações\n";
             
      } else {
          ajudaResultado1 = "";
                  
      }
       
        if (materia.equals("Sim")){
         ajudaResultado2 = "Busque falar com o seu professor "
                   + "preferencialmente em aula ou mande um email\n";
        
       } else {
            ajudaResultado2 = "";
        }
        
        
        
        if(social.equals("Sim")) {
        ajudaResultado3 = "Busque falar com o seu coordenador de "
                   + "socioemocional presencialmente, por whatsapp"
                   + " ou por email\n";
       } else {
            ajudaResultado3 = "Infelizmente não podemos te ajudar =(";
        }
       
 String concatenaResultados = String.format("%s\n%s\n%s",ajudaResultado1,
           ajudaResultado2, ajudaResultado3);
 String resultados = concatenaResultados;
   
       return resultados;
   }
   
   Double porcentagemFaltas (Integer numeroDeFaltas) {
       
        Double resultado = 0.0;
       
     
       
       System.out.println("Que matéria você quer ver?\n"
               + "1- Pesquisa e Inovação\n"
               + "2- Sistemas Operacionais\n"
               + "3- Linguagem de Programação\n"
               + "4- Análise de Sistemas\n"
               + "5- Socioemocional");
       Integer materia = leitor.nextInt();
       /*5 meses = 150 dias
       150 dias \ 7 = 21 semanas
       Se a cada semana eu tenho 10 faltas então 210 faltas em lp */
       
       
       
   if(materia == 1) {
        System.out.println("Quantas vezes você faltou segunda ou sexta-feira");
        numeroDeFaltas = leitor.nextInt();

        
       resultado = ( numeroDeFaltas * 100.0) / 210.0;
             
   } else if (materia == 2) {
       System.out.println("Quantas vezes você faltou em uma terça-feira?");
       numeroDeFaltas = leitor.nextInt();
   
       
       resultado = (numeroDeFaltas * 100.0) / 84.0;
   } else if (materia == 3) {
       System.out.println("Quantas vezes você faltou em uma quarta-feira?");
       numeroDeFaltas = leitor.nextInt();
       
       
       resultado = (numeroDeFaltas * 100.0) / 105.0;
   } else if (materia == 4) {
       System.out.println("Quantas vezes você faltou em uma quinta-feira?");
       numeroDeFaltas = leitor.nextInt();
    
       
       resultado = (numeroDeFaltas * 100.0) / 84.0;
   } else if (materia == 5) {
       System.out.println("Quantas vezes você faltou em uma segunda, terça"
               + "ou quinta feira?");
       numeroDeFaltas = leitor.nextInt();
      
       
       resultado = (numeroDeFaltas * 100.0) / 63.0;
   }
                
       
       return resultado;
   }
   
   
   String joguinhoSptecher (Integer randomico, Integer pontuacao){
            pontuacao = 0;
       
       System.out.println("você tem 5 chances de adivinhar um número de"
               + " 0 a 5\n"
               + "Digite o primeiro número");
       Integer numeroUsuario = leitor.nextInt();
       
       if(numeroUsuario < 0 || numeroUsuario > 5 ){
           System.out.println("Digite um número de 0 a 5");
           numeroUsuario = leitor.nextInt();
       } else {
           
          for (int i = 1; i < 6; i ++) {
              
          randomico = ThreadLocalRandom.current().nextInt(0, 5);
          
              if(numeroUsuario == randomico) {
                  i = 1;
                  pontuacao ++;
                  
                 System.out.println("Parabéns você acertou!\n"
                         + "tente adivinhar o próximo");
                 
                 numeroUsuario = leitor.nextInt();
                
                  
              } else {
                  System.out.println("Você errou tente de novo");
                  numeroUsuario = leitor.nextInt();
              }
          }
          
           System.out.println("Você perdeu as 5 tentativas");
       }
       
   String resultadoJogo = String.format("Você obteve %d pontos\n"
           + "%d", pontuacao, randomico);
          return resultadoJogo;
   }
}

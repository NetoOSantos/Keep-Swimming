
package com.mycompany.projetoindividual;

import java.util.Scanner;
import javax.print.attribute.standard.Media;


public class ProjetoIndividual {
    
    public static void main(String[] args) {
        Scanner leitor = new Scanner(System.in);
        Utilitaria utils = new Utilitaria();
        
        System.out.println("SPTecher HELPER");           
        
               String menu = utils.menu("");
                 System.out.println(menu);        
        
        Integer numeroSelecionado = leitor.nextInt();
        
      if(numeroSelecionado < 1 || numeroSelecionado > 5) {
        System.out.println("Digite um número válido! ");
        numeroSelecionado = leitor.nextInt();
      }
      
      
          
     while (numeroSelecionado != 4) {
          
       switch (numeroSelecionado) {
           case 1: 
        System.out.println("Digite a nota da Avaliação continuada");               
                    Double continuada = leitor.nextDouble();
       
        System.out.println("Digite a nota da Avaliação Integrada");               
                    Double integrada = leitor.nextDouble();
        
 
        Double media = utils.calcularMedia(continuada, integrada);
        
        String resultadoMedia = String.format(
                "Sua média de final de semestre foi %.2f", media);
               System.out.println(resultadoMedia);
               
               
               System.out.println(menu);
               numeroSelecionado = leitor.nextInt();
          
          break;
           case 2:
             
     String resultado = utils.precisoDeAjuda("Sim", "Sim", "Sim");
                     System.out.println(resultado);
   
                System.out.println(menu);
               numeroSelecionado = leitor.nextInt();
                        
           break;
               case 3:
          Double porcentagemFaltas = utils.porcentagemFaltas(200);
          
 String faltasResultado = String.format("Você está com %.0f%% de faltas nessa "
               + "matéria\n", porcentagemFaltas);
       
                   System.out.println(faltasResultado);
                   
                         System.out.println(menu);
                    numeroSelecionado = leitor.nextInt();
                        
           break;
               case 4:
               
           break;
               case 5:
               String joguinho = utils.joguinhoSptecher(1,1);
               
                   System.out.println(joguinho);
                   
                   System.out.println(menu);
                  numeroSelecionado = leitor.nextInt();
               
           break;
           default:
               System.out.println("Digite um número válido");
                numeroSelecionado = leitor.nextInt();
               break;
             }
                
        }
     System.out.println("Espero que o programa tenha te ajudado!");
    }
}
